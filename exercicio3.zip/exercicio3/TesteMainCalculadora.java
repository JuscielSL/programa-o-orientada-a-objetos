package exercicio3; 

public class TesteMainCalculadora{
    public static void main(String[] args){
        Calculadora calc = new Calculadora();
        calc.somar(4, 7);
        calc.somar(4.8, 5.0);
        System.out.println("O resultado da soma com numeros inteiros e: " + calc.somar(4, 7));
        System.out.println("O resultado da soma com numeros fracionarios e: " + calc.somar(4.8, 5.0));
}

}