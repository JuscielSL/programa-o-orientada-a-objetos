package exercicio3;

public class Calculadora {

    public Integer somar(Integer numero1, Integer numero2) {
        return numero1 + numero2;
    }
    public double somar(double numero1, Double numero2) {
        return numero1 + numero2;
    }
}
